{-# LANGUAGE NoMonomorphismRestriction #-}

module Acme.Pirates where

import System.IO
import System.Exit
import Control.Exception
import Prelude hiding (catch)

forPlunder = ReadMode

forSafeKeeping = WriteMode

digUpChest = openFile

buryChest = hClose

loadDoubloon = hGetChar

loadCashBox = hGetLine

stowDoubloon = hPutChar

stowCashBox = hPutStrLn

readTreasureMap = hTell

xMarksTheSpot = hSeek

loadTheTreasure = hGetContents

abandonShip = exitWith

whatSayYe = getLine

collectDoubloon = getChar

pollySquawks = putChar

pollySays = putStr . ("Yar. " ++)

captainsLog = hPutStr stderr

-- The crew gives the captain the black spot to inform him of a mutiny.
theBlackSpot = throwIO

-- The captain tries to give orders in the first parameter. This may result in a mutiny, which is handled in the second parameter.
mutiny = catch

-- Miscellaneous interjections
shiverMeTimbers = id

yar = id

meMateys = id
