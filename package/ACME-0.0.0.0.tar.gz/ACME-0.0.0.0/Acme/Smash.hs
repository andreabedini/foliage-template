module Acme.Smash where

import Data.List
import Data.Maybe
import Control.Monad
import Data.List.Extras.Argmax

-- | smash "THE ONE" "NEO" == "THE ONEO"
smash s s2 = fst $ argmax (\(x, y) -> length x * y) [ let Just (x, y) = find (\(_, tl2) -> isPrefixOf tl2 tl) $ zip (inits it) (tails it) in
	(x ++ tl, length y)
	| it <- inits s, tl <- tails s2 ]

