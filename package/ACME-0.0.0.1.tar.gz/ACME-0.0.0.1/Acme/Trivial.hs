-- | The Trivial monad.
module Acme.Trivial where

data Trivial t = Trivial deriving (Eq, Ord, Show, Read)

instance Functor Trivial where
	fmap _ Trivial = Trivial

instance Monad Trivial where
	return _ = Trivial
	Trivial >>= _ = Trivial
