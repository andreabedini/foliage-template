module Acme.Unit where

import Control.Monad.Identity (Identity(Identity))

-- | /Generalized unit types/

class Unit t where
	unit :: t

instance Unit () where
	unit = ()

instance (Unit t, Unit u) => Unit (t, u) where
	unit = (unit, unit)

instance (Unit t, Unit u, Unit v) => Unit (t, u, v) where
	unit = (unit, unit, unit)

instance (Unit t, Unit u, Unit v, Unit w) => Unit (t, u, v, w) where
	unit = (unit, unit, unit, unit)

instance (Unit t, Unit u, Unit v, Unit w, Unit x) => Unit (t, u, v, w, x) where
	unit = (unit, unit, unit, unit, unit)

instance (Unit t) => Unit (Identity t) where
	unit = Identity unit

instance (Unit u) => Unit (t -> u) where
	unit = const unit

