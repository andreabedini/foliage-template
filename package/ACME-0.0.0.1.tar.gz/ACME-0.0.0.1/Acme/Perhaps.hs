-- | The Perhaps monad
module Acme.Perhaps where

data Perhaps t = Definitely t | Probably t | ProbablyNot | Nope deriving (Eq, Ord, Show, Read)

instance Monad Perhaps where
	return = Definitely
	Definitely x >>= f = f x
	Probably x >>= f = case f x of
		Definitely y -> Probably y
		_ -> f x
	ProbablyNot >>= _ = ProbablyNot
	Nope >>= _ = Nope
